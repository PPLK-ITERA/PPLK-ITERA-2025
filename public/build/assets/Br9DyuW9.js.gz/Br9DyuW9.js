import{j as a}from"./Lul_5bI4.js";import{c as e}from"./Iw5Bc_ld.js";
/**
 * @license @tabler/icons-react v3.11.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var s=e("outline","loader-2","IconLoader2",[["path",{d:"M12 3a9 9 0 1 0 9 9",key:"svg-0"}]]);function r({className:e}){return a.jsx("div",{className:`w-6 h-6 ${e} grid place-content-center`,children:a.jsx(s,{className:"animate-spin"})})}export{r as R};
