import{r as e}from"./B2ezQRtC.js";
/**
 * @license lucide-react v0.399.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=(...e)=>e.filter(((e,r,o)=>Boolean(e)&&o.indexOf(e)===r)).join(" ")
/**
 * @license lucide-react v0.399.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */;var o={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};
/**
 * @license lucide-react v0.399.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=e.forwardRef((({color:t="currentColor",size:s=24,strokeWidth:a=2,absoluteStrokeWidth:i,className:n="",children:c,iconNode:l,...d},m)=>e.createElement("svg",{ref:m,...o,width:s,height:s,stroke:t,strokeWidth:i?24*Number(a)/Number(s):a,className:r("lucide",n),...d},[...l.map((([r,o])=>e.createElement(r,o))),...Array.isArray(c)?c:[c]]))),s=(o,s)=>{const a=e.forwardRef((({className:a,...i},n)=>{return e.createElement(t,{ref:n,iconNode:s,className:r(`lucide-${c=o,c.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase()}`,a),...i});var c}));return a.displayName=`${o}`,a};
/**
 * @license lucide-react v0.399.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */export{s as c};
