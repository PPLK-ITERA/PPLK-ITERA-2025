import{e as s,n as a,o as e,p as l,a2 as r,q as n}from"./CCUpqr-2.js";import{j as t}from"./CyvCi0KX.js";import{B as d}from"./BiTYtoFI.js";import{P as o}from"./CeZbInz0.js";
/**
 * @license @tabler/icons-react v3.11.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var i=s("outline","adjustments-horizontal","IconAdjustmentsHorizontal",[["path",{d:"M14 6m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0",key:"svg-0"}],["path",{d:"M4 6l8 0",key:"svg-1"}],["path",{d:"M16 6l4 0",key:"svg-2"}],["path",{d:"M8 12m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0",key:"svg-3"}],["path",{d:"M4 12l2 0",key:"svg-4"}],["path",{d:"M10 12l10 0",key:"svg-5"}],["path",{d:"M17 18m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0",key:"svg-6"}],["path",{d:"M4 18l11 0",key:"svg-7"}],["path",{d:"M19 18l1 0",key:"svg-8"}]]),c=s("outline","search","IconSearch",[["path",{d:"M10 10m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0",key:"svg-0"}],["path",{d:"M21 21l-6 -6",key:"svg-1"}]]);
/**
 * @license @tabler/icons-react v3.11.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */function h({options:s}){return t.jsxs(a,{children:[t.jsx(e,{asChild:!0,children:t.jsxs(d,{variant:"ghost",className:"flex gap-2 shadow-none",children:[t.jsx("span",{children:"Filter"}),t.jsx(i,{})]})}),t.jsx(l,{className:"bg-jaffa-100 rounded-lg",align:"end",children:t.jsx(r,{children:s.map((s=>t.jsx(n,{className:"place-content-end hover:bg-jaffa-200 px-2",children:t.jsxs("span",{className:"font-semibold",children:["Sort by ",s.label]})},s.value)))})})]})}function m({users:s,className:a}){return t.jsx("div",{className:`grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 mt-8 ${a}`,children:s.slice(0,10).map(((s,a)=>t.jsx(o,{user:s})))})}export{c as I,h as S,m as U};
